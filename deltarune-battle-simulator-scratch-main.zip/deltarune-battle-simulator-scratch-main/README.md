# deltarune-battle-simulator-scratch
a deltarune battle simulator made in scratch, built to be not too difficult to modify
